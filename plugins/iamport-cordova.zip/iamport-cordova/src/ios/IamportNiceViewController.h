#import "IamportPaymentViewController.h"

@interface IamportNiceViewController: IamportPaymentViewController
@property (strong, nonatomic) NSString *userKey;
@end
