#import "IamportPaymentViewController.h"

@interface IamportInicisViewController: IamportPaymentViewController
@end