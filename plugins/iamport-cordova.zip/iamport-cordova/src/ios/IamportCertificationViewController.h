//
//  IamportCertificationViewController.h
//  IamportCordovaExample
//
//  Created by deedee on 2019/12/23.
//

#import "IamportViewController.h"

@interface IamportCertificationViewController: IamportViewController
@end
