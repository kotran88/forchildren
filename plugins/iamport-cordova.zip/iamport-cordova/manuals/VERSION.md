# 버전정보

아임포트 코르도바 플러그인 버전 정보 안내입니다.

- [v0.9.3](https://github.com/iamport/iamport-cordova/tree/master)
  - IOS에서 UIWebView를 WKWebView로 대체하였습니다.

- [v0.9.2](https://github.com/iamport/iamport-cordova/tree/v0.9.2)
  - IOS에서 결제 및 휴대폰 소액결제 지원을 위한 코드 작성을 완료했습니다.

- [v0.9.1](https://github.com/iamport/iamport-cordova/tree/v0.9.1)
  - 안드로이드에서 웹뷰 ID 참조 방법을 변경하였습니다.

- [v0.9.0](https://github.com/iamport/iamport-cordova/tree/v0.9.0)
  - 안드로이드만 지원합니다.
  - 일반/정기결제 및 휴대폰 본인인증 기능을 제공합니다.